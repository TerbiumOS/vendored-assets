/*__FRX_OBF__*/var __frx$c02fec=(function(){function U(s){var b=atob(s),a=new Uint8Array(b.length),i=0;for(;i<b.length;i++)a[i]=b.charCodeAt(i);return a}function R(a,b){return((a<<b)|(a>>>(32-b)))>>>0}function CC(k,n,d){var K=new Uint32Array(8),N=new Uint32Array(3),o=new Uint8Array(d.length),S=new Uint32Array(16),W=new Uint32Array(16),ct=0,i,off,r,bl=new Uint8Array(64),v,nn;function Q(a,b,c,e){W[a]=(W[a]+W[b])>>>0;W[e]=R(W[e]^W[a],16);W[c]=(W[c]+W[e])>>>0;W[b]=R(W[b]^W[c],12);W[a]=(W[a]+W[b])>>>0;W[e]=R(W[e]^W[a],8);W[c]=(W[c]+W[e])>>>0;W[b]=R(W[b]^W[c],7)}for(i=0;i<8;i++)K[i]=(k[i*4]|(k[i*4+1]<<8)|(k[i*4+2]<<16)|(k[i*4+3]<<24))>>>0;for(i=0;i<3;i++)N[i]=(n[i*4]|(n[i*4+1]<<8)|(n[i*4+2]<<16)|(n[i*4+3]<<24))>>>0;for(off=0;off<d.length;off+=64){S[0]=0x61707865;S[1]=0x3320646e;S[2]=0x79622d32;S[3]=0x6b206574;S[4]=K[0];S[5]=K[1];S[6]=K[2];S[7]=K[3];S[8]=K[4];S[9]=K[5];S[10]=K[6];S[11]=K[7];S[12]=ct>>>0;S[13]=N[0];S[14]=N[1];S[15]=N[2];for(i=0;i<16;i++)W[i]=S[i];for(r=0;r<10;r++){Q(0,4,8,12);Q(1,5,9,13);Q(2,6,10,14);Q(3,7,11,15);Q(0,5,10,15);Q(1,6,11,12);Q(2,7,8,13);Q(3,4,9,14)}for(i=0;i<16;i++){v=(W[i]+S[i])>>>0;bl[i*4]=v&255;bl[i*4+1]=(v>>>8)&255;bl[i*4+2]=(v>>>16)&255;bl[i*4+3]=(v>>>24)&255}nn=Math.min(64,d.length-off);for(i=0;i<nn;i++)o[off+i]=d[off+i]^bl[i];ct++}return o}var K=U("jdSZ6B1wPi3L/5KvjkYK++7IAeypj+iLp5JN3Bdo2LQ="),P=["kx7uv5kAQxeuRMmMlT+TYk6vuU4B","pzW4x0iPNE4vfpqt1mQfwSmGoelIteEGlYsnHAW4skltVyC6YFv0IhFuw1FD2B98AmoQjgDt","eIUu+bSc2Cld4GUqD4bWNeQnpGg6","DoTYL2gubH0LTw84hpsr63xKJAx06uQd","EJJfRjy9flir9Wymr1cQZIN1tdxcSMpIJdgqkanN8jbPJlifSA/OS1n15SRiWoJ/caUNbF78rww=","YdV+KmiH37vnOrNY027WnMp8OVjWL1TPdHp2","EDKjjklSE1fvKQfzv7qJG/4r5ycZ0x2sgD55afpJXY7ycg0=","lOyCa3RqjblXa/dNjw==","XBRlGVNMuIMWOahnWioQx6gFfCxOsyj/QMIY1D44vYuwaQ==","2GwEcN+iIneVKQbfm+YAhpNooJ1Z","upW8M8k5r3ihxwTRMMbPv6By4Fl5/uM=","UM8T4Nh2U3xGNuLLgemMZeIEqA==","jHvKqLRP3kBE781OpQQYS54feRIkHpzUmZi/rcKqbfnD","Tsqp+3e12JJvjuHCDVAl6SEUpFjp","mrMjuBb2Sgj87SZe9grsVlhjHOo1PnI=","mYYRyGmnqYDxpi9pAIyvGxuSBn4=","T68FDEcznPRZkZ7y+8eGuwnY6oF7tZHjEdqDi452U4Lx","NJqTdzumff6uRwNTIVzu7BpzYndeMKBxg9D07hsirIZnx3cQcvAtN10iEy8rvbVLUpEj1tYSMw==","3yHI452Yi5WJZUojGplbzq/GtO/U","8dGywV0NhuBEKaOUkFJyk9hQYBlTsXx3kXDC5qjHxrFuZDSPHrTf8ISRrLc6iaTA0deKDkaZ7AJHCw64I4nm","XGGpsKhOY+vzvm03Noo4WGaKgKxSvV1mxDotbJjiAU9cy7ifYm994WlqewfkjJ7R3jLhyh06cyIQrwicFbZV","sbAMWHjwX529D+l2DwcH2tPyRwqXDGXlRqupKUbfKvOsph2pEaKRbDSR79k59kdqEbtmlysoAikg7zwH","0gG6um7Rkh7+gjVt94OgV6m4","gQJh8aqAWVOoyUkv6eoi","f7qfc+dPsHwMHQwJdpfIYXZErrq0yisPqD9k","zrThQa5O94PpxlVcpC8zEgZCT/jh5hmOuSJRadLpqt0fucLJ","meWB7sfuG5DwhQI2+9sbw3W9kpWIdxpj+ppokUDCDeJ9yEMUKi/HzFiNwUhmxchxV17pSf5YZgkjB4FKhcEwCWfROWuU8pWa4ECkbkfHfywdp6zD4PKEbmEhF8ZarTNPu+3TTXe/6O3Hyd0mb6MiygADr1CHcCrtJT0+qiw05EW/nV6t8mXOtdSYZ3ZeaMvG","oybJRIhz94+43kIpRAmYOIAjZQqOWziVHVd3l7hWIkhvYMycKc+3CQ==","BFBpAEMSHK9oLxphinwsTLy8FKBuakCQK3lZ0iw6lD5V0oDczicK5Ge49LKQP7CmlGdjQYdLlDk=","rKjZs+ooocm2q7p72xYMyTyGAvRPOu0hEAXMdR/fCdLk0A==","YYD576/GoRF1yT4TiXAzxWUihjuiqwTeysinbgeEEiwyJi3O6+krOpQwe7auDqWIUgm12SRtVNTOoNrztlHhEYUzEz6awBfGvSuA9i18wgIJzxbmNKRE/7Mx/VUuLvyBSBJQsHhSKNyJzMKJQE3/mAK7GiDItnmz299Cxg==","Jhoz76wiLs8mbUs8hvnL3lbQOccOC+fJsOzTIFmrp2buFLYnp50xcl4=","Iow8s0R6k9nq1n3R4XF2MbCD/VFVt2GVxn74wtQYAoZ63XXBHDSkbcZxwNweiA==","wUXYC48lw51YPQi4R3K9EU/9j8DS/uQj4fhzUwgDIG7H4Y0YRLCYbKoJIyGOKR6ubiRU1m6tjQ==","PY2BSB/w4HpPbOZjrUz21RKuPj3n1ZJ7g5v1Gnkgs48tFLN7EjL9ZjLLVwCiG0eHra9Ua9mPY6eyeGgERaW3qOhwaDe9JHh8VdAqsLDHZlw1YjrHjKnurEo=","lrwjRYs1R4qXDfCRv5YhpPiC1Q==","CYa1WlDhoEfmXaE7OYfn04Iitw==","ogvrVQ5uuQwJn+p8orxHkEf2Cg==","X6WtApDSU0xu4OPmFrCiZmwu","nkwyBFZG1Sr6AxIdvDOIfp18eYeMgKQRSvqPbg==","MmKXaASzmEAfoWqsweZuNQpqUu4Adg==","cXuuZwWPNkmF5qqf6dmc2+cFVVM=","JZGzSuJRP02wRkVNEgEii1A=","V+CDhrnMNXjsH/UAoUiFKjFaFkioJWRk","MGNnYQjmjoMW7AjLiQ==","QESPzbUXTLZLFdspIzAw","jEAN8lhcBaM5fZ24vSFJPy2ESqGAjAk=","A9i0bAW+IP2gBXvrWoVhjhuCfb0q6+/VTC6oLA==","Ij08th7wVuVfJZon759NBkAeyLA=","0C0JwyE/vuQfRs28gmja","13u/W7LgIY7EO7qsR790qXR8Ljlt03RLWg==","hlUn/Od/HaQk5rZzfZWyQno=","esc4ZcPk66xodZixWV4="],C=[],TD=new TextDecoder();return function(i){if(C[i]!==void 0)return C[i];var raw=U(P[i]),n=raw.subarray(0,12),c=raw.subarray(12);return C[i]=TD.decode(CC(K,n,c))}})();
/**
 * Terbium Frameless Window Helper v2.7
 *
 * Helper utilities for building apps with frameless/custom windows in Terbium.
 * This library handles the complex coordinate math and messaging required for
 * frameless window dragging to work identically to standard Terbium windows.
 *
 * Frameless windows now support ALL the same behaviors as normal windows:
 * - Click, hold, and drag to move (real-time, smooth dragging)
 * - Double-click to maximize/restore
 * - Edge snapping with preview
 * - Smooth transitions and animations
 * - Window controls (minimize, maximize, close)
 * - Proper click handling (simple clicks work normally, no interference)
 *
 * HOW IT WORKS:
 * The helper sends continuous mouse position updates to the parent window during
 * drag operations. This allows smooth, real-time window movement even though the
 * mouse events originate inside the iframe.
 *
 * @example Basic usage:
 * ```html
 * <script src="/terbium-frameless.js"></script>
 * <script>
 *   TerbiumFrameless.init({
 *     dragSelector: '.my-titlebar',
 *     noDragSelectors: ['.window-controls', 'button', 'input'],
 *     enableDoubleClick: true  // Enable double-click to maximize (default: true)
 *   });
 * </script>
 * ```
 *
 * @example Manual drag trigger:
 * ```javascript
 * element.addEventListener('mousedown', function(e) {
 *   if (shouldDrag) {
 *     TerbiumFrameless.startDrag(e);
 *   }
 * });
 * ```
 */
(function (window) {
	"use strict";
	const TerbiumFrameless = {
		_initialized: new WeakSet(),
		/**
		 * Initialize frameless window drag behavior
		 * Makes frameless windows behave identically to standard Terbium windows
		 *
		 * Drag behavior:
		 * - Prevents text selection when clicking titlebar
		 * - Drag only starts when mouse moves while button is held
		 * - Uses original mousedown coordinates for proper offset calculation
		 * - Exactly matches normal window behavior
		 *
		 * @param {Object} options Configuration options
		 * @param {string} options.dragSelector - CSS selector for draggable area (e.g., '.titlebar')
		 * @param {string[]} options.noDragSelectors - CSS selectors that should NOT trigger drag
		 * @param {boolean} options.enableDoubleClick - Enable double-click to maximize (default: true)
		 *                                               Respects the doubleClickMaximize setting in window config
		 * @param {Function} options.onDragStart - Callback when drag starts (only fires on mouse movement)
		 * @param {Function} options.onDragEnd - Callback when drag ends (only fires if drag actually started)
		 */
		init: function (options) {
			const config = {
				dragSelector: options.dragSelector || __frx$c02fec(0),
				noDragSelectors: options.noDragSelectors || [],
				enableDoubleClick: options.enableDoubleClick !== false,
				onDragStart: options.onDragStart || null,
				onDragEnd: options.onDragEnd || null,
			};
			const dragElement = document.querySelector(config.dragSelector);
			if (!dragElement) {
				console.warn(__frx$c02fec(1), config.dragSelector);
				return;
			}
			if (this._initialized.has(dragElement)) return;
			this._initialized.add(dragElement);
			const begin = function (e) {
				// Pointer events are supported by the Terbium browser. Keep the
				// mouse fallback for older hosts, but never start both handlers for
				// the same physical press.
				if (e.type === __frx$c02fec(2) && __frx$c02fec(3) in window) return;
				const target = e.target instanceof Element ? e.target : null;
				for (const selector of config.noDragSelectors) {
					if (target?.closest(selector)) {
						return;
					}
				}
				e.preventDefault();
				const iframeRect = window.frameElement?.getBoundingClientRect();
				if (!iframeRect) {
					console.warn(__frx$c02fec(4));
					return;
				}
				let dragStarted = false;
				const frame = window.frameElement;
				const wid = frame?.closest(__frx$c02fec(5))?.id;
				if (!wid) return;
				const startParentX = e.clientX + iframeRect.left;
				const startParentY = e.clientY + iframeRect.top;
				const onMouseMove = function (moveEvent) {
					const currentRect = window.frameElement?.getBoundingClientRect();
					if (!currentRect) return;
					const parentX = moveEvent.clientX + currentRect.left;
					const parentY = moveEvent.clientY + currentRect.top;
					if (!dragStarted) {
						dragStarted = true;
						window.parent.postMessage(
							{
								type: __frx$c02fec(6),
								wid: wid,
								parentX: startParentX,
								parentY: startParentY,
							},
							__frx$c02fec(7),
						);
						if (config.onDragStart) {
							config.onDragStart(e);
						}
					}
					window.parent.postMessage(
						{
							type: __frx$c02fec(8),
							wid: wid,
							parentX: parentX,
							parentY: parentY,
						},
						__frx$c02fec(7),
					);
				};
				const onMouseUp = function () {
					document.removeEventListener(__frx$c02fec(9), onMouseMove);
					document.removeEventListener(__frx$c02fec(10), onMouseMove);
					document.removeEventListener(__frx$c02fec(11), onMouseUp);
					if (dragStarted) {
						window.parent.postMessage(
							{
								type: __frx$c02fec(12),
								wid: wid,
							},
							__frx$c02fec(7),
						);
						if (config.onDragEnd) {
							config.onDragEnd();
						}
					}
				};
				if (e.pointerId !== undefined && dragElement.setPointerCapture) {
					try { dragElement.setPointerCapture(e.pointerId); } catch (_) {}
				}
				document.addEventListener(__frx$c02fec(9), onMouseMove);
				document.addEventListener(__frx$c02fec(11), onMouseUp);
				document.addEventListener(__frx$c02fec(10), onMouseMove);
				document.addEventListener(__frx$c02fec(13), onMouseUp, { once: true });
			};
			dragElement.addEventListener(__frx$c02fec(2), begin);
			dragElement.addEventListener(__frx$c02fec(14), begin);
			if (config.enableDoubleClick) {
				dragElement.addEventListener(__frx$c02fec(15), function (e) {
					const target = e.target instanceof Element ? e.target : null;
					for (const selector of config.noDragSelectors) {
						if (target?.closest(selector)) {
							return;
						}
					}
					const iframeRect = window.frameElement?.getBoundingClientRect();
					if (iframeRect) {
						window.parent.postMessage(
							{
								type: __frx$c02fec(16),
								wid: window.frameElement?.closest(__frx$c02fec(5))?.id,
							},
							__frx$c02fec(7),
						);
					} else {
						TerbiumFrameless.maximize();
					}
				});
			}
			console.log(__frx$c02fec(17), config);
		},
		/**
		 * Start a drag operation (can be called manually)
		 * @param {MouseEvent} e - The mousedown event
		 */
		startDrag: function (e) {
			e.preventDefault();
			const iframeRect = window.frameElement?.getBoundingClientRect();
			if (!iframeRect) {
				console.warn(__frx$c02fec(4));
				return;
			}
			const parentClientX = e.clientX + iframeRect.left;
			const parentClientY = e.clientY + iframeRect.top;
			window.parent.postMessage(
				{
					type: __frx$c02fec(6),
					wid: window.frameElement?.closest(__frx$c02fec(5))?.id,
					parentX: parentClientX,
					parentY: parentClientY,
				},
				__frx$c02fec(7),
			);
		},
		/**
		 * Start drag from a specific element region (useful for canvas-based UIs)
		 * @param {MouseEvent} e - The mousedown event
		 * @param {Object} bounds - The bounds to check { top, bottom, left, right } in pixels
		 * @returns {boolean} - Whether drag was initiated
		 */
		startDragInBounds: function (e, bounds) {
			const element = e.target;
			const rect = element.getBoundingClientRect();
			const relativeX = e.clientX - rect.left;
			const relativeY = e.clientY - rect.top;
			if ((bounds.top === undefined || relativeY >= bounds.top) && (bounds.bottom === undefined || relativeY <= bounds.bottom) && (bounds.left === undefined || relativeX >= bounds.left) && (bounds.right === undefined || relativeX <= bounds.right)) {
				this.startDrag(e);
				return true;
			}
			return false;
		},
		/**
		 * Maximize the current window (uses Terbium API)
		 */
		maximize: function () {
			if (typeof tb !== __frx$c02fec(18) && tb.window && tb.window.maximize) {
				tb.window.maximize();
			} else {
				console.warn(__frx$c02fec(19));
			}
		},
		/**
		 * Minimize the current window (uses Terbium API)
		 */
		minimize: function () {
			if (typeof tb !== __frx$c02fec(18) && tb.window && tb.window.minimize) {
				tb.window.minimize();
			} else {
				console.warn(__frx$c02fec(20));
			}
		},
		/**
		 * Close the current window (uses Terbium API)
		 */
		close: function () {
			if (typeof tb !== __frx$c02fec(18) && tb.window && tb.window.close) {
				tb.window.close();
			} else {
				console.warn(__frx$c02fec(21));
			}
		},
		/**
		 * Helper to create standard window control buttons
		 * @param {HTMLElement} container - Container element to append buttons to
		 * @param {Object} options - Options for controls
		 * @param {boolean} options.minimize - Show minimize button (default: true)
		 * @param {boolean} options.maximize - Show maximize button (default: true)
		 * @param {boolean} options.close - Show close button (default: true)
		 * @param {string} options.theme - Theme style: 'windows', 'macos', 'chrome' (default: 'chrome')
		 * @returns {Object} - Object with button elements { minimize, maximize, close }
		 */
		createControls: function (container, options) {
			const config = {
				minimize: options.minimize !== false,
				maximize: options.maximize !== false,
				close: options.close !== false,
				theme: options.theme || __frx$c02fec(22),
			};
			const controls = {};
			const controlsDiv = document.createElement(__frx$c02fec(23));
			controlsDiv.className = __frx$c02fec(24);
			const themes = {
				chrome: {
					container: __frx$c02fec(25),
					button: __frx$c02fec(26),
					hover: __frx$c02fec(27),
					closeHover: __frx$c02fec(28),
				},
				windows: {
					container: __frx$c02fec(29),
					button: __frx$c02fec(30),
					hover: __frx$c02fec(31),
					closeHover: __frx$c02fec(32),
				},
				macos: {
					container: __frx$c02fec(33),
					button: __frx$c02fec(34),
					colors: { close: __frx$c02fec(35), minimize: __frx$c02fec(36), maximize: __frx$c02fec(37) },
				},
			};
			const theme = themes[config.theme] || themes.chrome;
			controlsDiv.style.cssText = theme.container;
			if (config.minimize) {
				const btn = document.createElement(__frx$c02fec(38));
				btn.className = __frx$c02fec(39);
				btn.setAttribute(__frx$c02fec(40), __frx$c02fec(41));
				if (config.theme === __frx$c02fec(42)) {
					btn.style.cssText = theme.button + (__frx$c02fec(43)+String(theme.colors.minimize)+__frx$c02fec(44));
				} else {
					btn.textContent = __frx$c02fec(45);
					btn.style.cssText = theme.button;
					btn.onmouseover = () => (btn.style.background = theme.hover);
					btn.onmouseout = () => (btn.style.background = __frx$c02fec(46));
				}
				btn.onclick = () => this.minimize();
				controlsDiv.appendChild(btn);
				controls.minimize = btn;
			}
			if (config.maximize) {
				const btn = document.createElement(__frx$c02fec(38));
				btn.className = __frx$c02fec(47);
				btn.setAttribute(__frx$c02fec(40), __frx$c02fec(48));
				if (config.theme === __frx$c02fec(42)) {
					btn.style.cssText = theme.button + (__frx$c02fec(43)+String(theme.colors.maximize)+__frx$c02fec(44));
				} else {
					btn.textContent = __frx$c02fec(49);
					btn.style.cssText = theme.button;
					btn.onmouseover = () => (btn.style.background = theme.hover);
					btn.onmouseout = () => (btn.style.background = __frx$c02fec(46));
				}
				btn.onclick = () => this.maximize();
				controlsDiv.appendChild(btn);
				controls.maximize = btn;
			}
			if (config.close) {
				const btn = document.createElement(__frx$c02fec(38));
				btn.className = __frx$c02fec(50);
				btn.setAttribute(__frx$c02fec(40), __frx$c02fec(51));
				if (config.theme === __frx$c02fec(42)) {
					btn.style.cssText = theme.button + (__frx$c02fec(43)+String(theme.colors.close)+__frx$c02fec(44));
				} else {
					btn.textContent = __frx$c02fec(52);
					btn.style.cssText = theme.button;
					btn.onmouseover = () => (btn.style.cssText = theme.button + theme.closeHover);
					btn.onmouseout = () => (btn.style.cssText = theme.button);
				}
				btn.onclick = () => this.close();
				controlsDiv.appendChild(btn);
				controls.close = btn;
			}
			container.appendChild(controlsDiv);
			return controls;
		},
	};
	window.TerbiumFrameless = TerbiumFrameless;
})(window);
