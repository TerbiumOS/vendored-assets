/*__FRX_OBF__*/var __frx$251a81=(function(){function U(s){var b=atob(s),a=new Uint8Array(b.length),i=0;for(;i<b.length;i++)a[i]=b.charCodeAt(i);return a}function R(a,b){return((a<<b)|(a>>>(32-b)))>>>0}function CC(k,n,d){var K=new Uint32Array(8),N=new Uint32Array(3),o=new Uint8Array(d.length),S=new Uint32Array(16),W=new Uint32Array(16),ct=0,i,off,r,bl=new Uint8Array(64),v,nn;function Q(a,b,c,e){W[a]=(W[a]+W[b])>>>0;W[e]=R(W[e]^W[a],16);W[c]=(W[c]+W[e])>>>0;W[b]=R(W[b]^W[c],12);W[a]=(W[a]+W[b])>>>0;W[e]=R(W[e]^W[a],8);W[c]=(W[c]+W[e])>>>0;W[b]=R(W[b]^W[c],7)}for(i=0;i<8;i++)K[i]=(k[i*4]|(k[i*4+1]<<8)|(k[i*4+2]<<16)|(k[i*4+3]<<24))>>>0;for(i=0;i<3;i++)N[i]=(n[i*4]|(n[i*4+1]<<8)|(n[i*4+2]<<16)|(n[i*4+3]<<24))>>>0;for(off=0;off<d.length;off+=64){S[0]=0x61707865;S[1]=0x3320646e;S[2]=0x79622d32;S[3]=0x6b206574;S[4]=K[0];S[5]=K[1];S[6]=K[2];S[7]=K[3];S[8]=K[4];S[9]=K[5];S[10]=K[6];S[11]=K[7];S[12]=ct>>>0;S[13]=N[0];S[14]=N[1];S[15]=N[2];for(i=0;i<16;i++)W[i]=S[i];for(r=0;r<10;r++){Q(0,4,8,12);Q(1,5,9,13);Q(2,6,10,14);Q(3,7,11,15);Q(0,5,10,15);Q(1,6,11,12);Q(2,7,8,13);Q(3,4,9,14)}for(i=0;i<16;i++){v=(W[i]+S[i])>>>0;bl[i*4]=v&255;bl[i*4+1]=(v>>>8)&255;bl[i*4+2]=(v>>>16)&255;bl[i*4+3]=(v>>>24)&255}nn=Math.min(64,d.length-off);for(i=0;i<nn;i++)o[off+i]=d[off+i]^bl[i];ct++}return o}var K=U("KHdSc155bKrG7+yEJVwABis3xrKyWXds+WPhzuN41uw="),P=["6tQUlbRyI3arkxu7kA==","BGuifSavKGwz7w1okdocEow=","5Pxk5An5Gmoqn2g3/S/y","Tqv2FGXqJODT2KltvmTI4Q66V0JPiA=="],C=[],TD=new TextDecoder();return function(i){if(C[i]!==void 0)return C[i];var raw=U(P[i]),n=raw.subarray(0,12),c=raw.subarray(12);return C[i]=TD.decode(CC(K,n,c))}})();
importScripts("./vendor/ctl.sw.js");
// UV: its bundle, config and worker under this build's names (vite.config.ts UV_FILES).
importScripts("./vendor/pl.js");

const uv = new NKCbqkfjlOujxxl();

// Buffer request bodies before handing them to the routing layer, which otherwise transfers `request.body` to the page:
// - Firefox doesn't implement Request.body, so every POST would be forwarded with an empty body.
// - In Chromium, the transferred stream of sendBeacon/keepalive requests never finishes. Those requests then hang
//   forever, fill the transport's per-host connection limit and stall every later request to the same site.
const withBufferedBody = async e => {
	const request = e.request;
	if (request.method === "GET" || request.method === "HEAD") return e;
	const buffer = await request.arrayBuffer();
	const body = buffer.byteLength ? buffer : null;
	return {
		clientId: e.clientId,
		resultingClientId: e.resultingClientId,
		request: new Proxy(request, {
			get(target, prop) {
				if (prop === "body") return body;
				const value = Reflect.get(target, prop, target);
				return typeof value === "function" ? value.bind(target) : value;
			},
		}),
	};
};

// A worker that has only just started knows no controller: the page's controller registers with it by message, after a
// worker of a new build took the page over (every deploy: this file differs with each build) or when the browser starts
// the worker again after stopping it idle. A request for a proxied URL that came first was let through to the server,
// which has no such path: the page got its 404, or a proxied document ran without the scripts that contain it. Such a
// request waits for its controller instead.
const ENGINE_PREFIX = "/~/sj/"; // the controller's default prefix (App.tsx passes none)
const CONTROLLER_WAIT_MS = 5000;
const controllerFor = async e => {
	const until = Date.now() + CONTROLLER_WAIT_MS;
	while (!(globalThis[__frx$251a81(0)+__frx$251a81(1)+__frx$251a81(2)+__frx$251a81(3)]).shouldRoute(e)) {
		if (Date.now() > until) return false;
		await new Promise(resolve => setTimeout(resolve, 20));
	}
	return true;
};
const route = e => withBufferedBody(e).then(event => (globalThis[__frx$251a81(0)+__frx$251a81(1)+__frx$251a81(2)+__frx$251a81(3)]).route(event));

// The page asks for this when it loaded without the worker (first visit, hard reload), so it doesn't have to reload.
self.addEventListener("message", e => {
	if (e.data === "claim") e.waitUntil(self.clients.claim());
});

self.addEventListener("fetch", e => {
	if (uv.route(e)) {
		e.respondWith(uv.fetch(e));
	} else if ((globalThis[__frx$251a81(0)+__frx$251a81(1)+__frx$251a81(2)+__frx$251a81(3)]).shouldRoute(e)) {
		e.respondWith(route(e));
	} else if (new URL(e.request.url).pathname.startsWith(ENGINE_PREFIX)) {
		// No controller within the wait: the page that made the URL is gone, and the server answers as it did.
		e.respondWith(controllerFor(e).then(found => (found ? route(e) : fetch(e.request))));
	}
});
